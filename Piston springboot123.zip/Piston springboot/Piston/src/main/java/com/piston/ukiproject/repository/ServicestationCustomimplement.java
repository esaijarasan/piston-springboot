package com.piston.ukiproject.repository;

import org.springframework.stereotype.Repository;

import com.piston.ukiproject.model.Servicestation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

@Repository
public class ServicestationCustomimplement implements ServicestationCustom{

	@Autowired
    MongoTemplate mongoTemplate;
 
    public Double getMinWorkId() {
        Query query = new Query();
        query.with(Sort.by(Sort.Direction.ASC, "workDistance"));
        query.limit(1);
       Servicestation minObject = mongoTemplate.findOne(query, Servicestation.class);
        if (minObject == null) {
            return null;
        }
        return minObject.getWorkDistance();
    }
}
