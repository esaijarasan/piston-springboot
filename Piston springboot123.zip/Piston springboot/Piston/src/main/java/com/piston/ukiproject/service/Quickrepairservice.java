package com.piston.ukiproject.service;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.piston.ukiproject.exception.RecordNotFoundException;
import com.piston.ukiproject.model.Quickrepair;
import com.piston.ukiproject.repository.QuickrepairRepository;





@Service
public class Quickrepairservice {
	
@Autowired
QuickrepairRepository quickrepairRepository;



public ResponseEntity<Quickrepair> createquickrepair(@Valid Quickrepair quickrepair) {
	try {
		quickrepair.setBookingdate(new Date());
		Quickrepair quickrepairs =quickrepairRepository.insert(quickrepair);
		return new ResponseEntity<>(quickrepairs,HttpStatus.CREATED);
	} catch (Exception e) {
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

	
}

public ResponseEntity<List<Quickrepair>> findByUserId(String userid) throws RecordNotFoundException {
	List<Quickrepair> quickrepairs = new ArrayList<Quickrepair>();
			
			quickrepairRepository.findByuserid(userid).forEach(quickrepairs::add);
	
			  if (quickrepairs.isEmpty()) {
			      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			    }
			    return new ResponseEntity<>(quickrepairs, HttpStatus.OK);
}

public ResponseEntity<List<Quickrepair>> findByServicestationid(String Servicestationid) throws RecordNotFoundException {
List<Quickrepair> quickrepairs =new ArrayList<Quickrepair>();

quickrepairRepository.findByServicestationid(Servicestationid).forEach(quickrepairs::add);
	

if (quickrepairs.isEmpty()) {
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
  return new ResponseEntity<>(quickrepairs, HttpStatus.OK);
}

public ResponseEntity<List<Quickrepair>> getAllHistory() {
	List<Quickrepair>quickrepairs= new ArrayList<Quickrepair>();
	quickrepairRepository.findAll().forEach(quickrepairs::add);;

    if (quickrepairs.isEmpty()) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    return new ResponseEntity<>(quickrepairs, HttpStatus.OK);
}

public ResponseEntity<Map<String, Object>> getAllQuickrepairInPage(int pageNo, int pageSize, String sortBy) {
	try {
  		 Map<String, Object> response = new HashMap<>();
  	 	Sort sort = Sort.by(sortBy);
  		 Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
  	 	Page<Quickrepair> page = quickrepairRepository.findAll(pageable);
  	 	response.put("data", page.getContent());
  	 	response.put("Total no of pages", page.getTotalPages());
  	 	response.put("Total no of elements", page.getTotalElements());
  	 	response.put("Current page no", page.getNumber());
  		 
  	 	return new ResponseEntity<>(response, HttpStatus.OK);
  	 } catch (Exception e) {
  	 	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
  	 }
}



		public ResponseEntity<HttpStatus> deleteAllHistory() {
			try {
				List<Quickrepair> repair=quickrepairRepository.findAll();
				
				if (repair.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				} else {
					quickrepairRepository.deleteAll(repair);
				}
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
			}

		public ResponseEntity<HttpStatus> deleteHistoryById(String id) {
			try {
				Optional<Quickrepair> repair=quickrepairRepository.findById(id);
				
				if (repair.isPresent()) {
					quickrepairRepository.delete(repair.get());
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
				
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

		

}




