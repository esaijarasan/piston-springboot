package com.piston.ukiproject.model;
import java.util.Arrays;
import java.util.Date;

import javax.validation.constraints.NotEmpty;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Quickrepair")
public class Quickrepair {

	@Id
	private String id;
	private String userid;
	private String servicestationid;
	private Date bookingdate;


	
	@NotEmpty(message = "vehicleTypes must not be empty")
	private String[] vehicleTypes;
	
	
	@NotEmpty(message = "phoneNumber must not be empty")
	private Integer phoneNumber;
	
	@NotEmpty(message = "vehicleTypes must not be empty")
	private String[] serviceType;

	
	public Quickrepair(String id, String userid, String servicestationid, Date bookingdate,
			@NotEmpty(message = "vehicleTypes must not be empty") String[] vehicleTypes,
			@NotEmpty(message = "phoneNumber must not be empty") Integer phoneNumber,
			@NotEmpty(message = "vehicleTypes must not be empty") String[] serviceType) {
		super();
		this.id = id;
		this.userid = userid;
		this.servicestationid = servicestationid;
		this.bookingdate = bookingdate;
		this.vehicleTypes = vehicleTypes;
		this.phoneNumber = phoneNumber;
		this.serviceType = serviceType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getServicestationid() {
		return servicestationid;
	}

	public void setServicestationid(String servicestationid) {
		this.servicestationid = servicestationid;
	}

	public Date getBookingdate() {
		return bookingdate;
	}

	public void setBookingdate(Date bookingdate) {
		this.bookingdate = bookingdate;
	}

	public String[] getVehicleTypes() {
		return vehicleTypes;
	}

	public void setVehicleTypes(String[] vehicleTypes) {
		this.vehicleTypes = vehicleTypes;
	}

	public Integer getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String[] getServiceType() {
		return serviceType;
	}

	public void setServiceType(String[] serviceType) {
		this.serviceType = serviceType;
	}

	@Override
	public String toString() {
		return "Quickrepair [id=" + id + ", userid=" + userid + ", servicestationid=" + servicestationid
				+ ", bookingdate=" + bookingdate + ", vehicleTypes=" + Arrays.toString(vehicleTypes) + ", phoneNumber="
				+ phoneNumber + ", serviceType=" + Arrays.toString(serviceType) + "]";
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}