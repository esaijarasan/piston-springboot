package com.piston.ukiproject.repository;

public interface ServicestationCustom {
	public Double getMinWorkId();
}